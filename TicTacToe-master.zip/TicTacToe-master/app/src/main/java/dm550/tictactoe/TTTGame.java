package dm550.tictactoe;

import java.util.Random;

/** main class creating a board and the GUI
 * defines the game play
 */
public class TTTGame implements Game {

    /** currently active player */
    public int currentPlayer;

    /** total number of players */
    private int numPlayers;
    
    /** the board we play on */
    private TTTBoard board;
    
    /** the gui for board games */
    private UserInterface ui;

    /**turn counter for AI games*/
    int turnCounter;
    
    /** constructor that gets the number of players */
    public TTTGame(int numPlayers) {
        if (numPlayers == 1){
            Random rnd = new Random();
            int startGen = rnd.nextInt(2); // randomize who starts in the player vs AI game
            if (startGen == 0){
                this.currentPlayer = 1;
            } else {
                this.currentPlayer = 7;
                turnCounter = 1;
            }
        } else {
            this.currentPlayer = 1;
        }
        this.numPlayers = numPlayers;
        this.board = new TTTBoard(numPlayers);
    }

    @Override
    public String getTitle() {
        if (numPlayers == 1 && currentPlayer == 1){
            return "TTT VS AI - Human player starts";
        } else if (numPlayers == 1 && currentPlayer == 7) {
            return "TTT VS AI - AI starts";
        } else{
            return this.numPlayers+"-way Tic Tac Toe";
        }
    }

    @Override
    public void addMove(Coordinate pos) {
        if (numPlayers == 1){
            if (currentPlayer == 1) {
                this.board.addMove(pos, this.currentPlayer);
                this.currentPlayer = 7;
            } else if (currentPlayer == 7) {
                this.board.addMove(pos, this.currentPlayer);
                this.currentPlayer = 1;
            }
            turnCounter++;
        } else {
            this.board.addMove(pos, this.currentPlayer);
            if (this.currentPlayer == this.numPlayers) {
                this.currentPlayer = 1;
            } else {
                this.currentPlayer++;
            }
        }
    }

    /**returns true if it's currently the players turn and false if it's the AI's turn*/
    @Override
    public Boolean playerTurn(){
        if (turnCounter % 2 == 0) {
            return true;
        }
        return false;
    }

    @Override
    public String getContent(Coordinate pos) {
        String result = "";
        int player = this.board.getPlayer(pos);
        if (player > 0) {
            result += player;
        }
        return result;
    }

    @Override
    public int getHorizontalSize() {
        return this.board.getSize();
    }

    @Override
    public int getVerticalSize() {
        return this.board.getSize();
    }

    @Override
    public void checkResult() {
        int winner = this.board.checkWinning();
        if (winner > 0) {
            this.ui.showResult("Player "+winner+" wins!");
        } else if (this.board.checkFull()) {
            this.ui.showResult("This is a DRAW!");
        }
    }

    @Override
    public boolean isFree(Coordinate pos) {
        return this.board.isFree(pos);
    }

    @Override
    public void setUserInterface(UserInterface ui) {this.ui = ui;}
    
    public String toString() {
        return "Board before Player "+this.currentPlayer+" of "+this.numPlayers+"'s turn:\n"+this.board.toString();
    }
}
