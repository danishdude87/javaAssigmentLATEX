package dm550.tictactoe;

import android.util.Log;

/** represents a tic tac toe board of a given size */
public class TTTBoard {
    
    /** 2-dimensional array representing the board
     * coordinates are counted from top-left (0,0) to bottom-right (size-1, size-1)
     * board[x][y] == 0   signifies free at position (x,y)
     * board[x][y] == i   for i > 0 signifies that Player i made a move on (x,y)
     */
    public int[][] board;
    
    /** size of the (quadratic) board */
    private int size;

    /** constructor for creating an empty board for a given number of players */
    public TTTBoard(int numPlayers) {
        if (numPlayers == 1){ // board of size 3x3 for AI game
            this.size = numPlayers + 2;
            this.board = new int[this.getSize()][this.getSize()];
        } else {
            this.size = numPlayers + 1;
            this.board = new int[this.getSize()][this.getSize()];
        }
    }
    
    /** checks whether the board is free at the given position */
    public boolean isFree(Coordinate c) {
        if (board[c.getX()][c.getY()] == 0) {
            return true;
        }
        return false;
    }

    /** returns the players that made a move on (x,y) or 0 if the position is free */
    public int getPlayer(Coordinate c) {
        return board[c.getX()][c.getY()];
    }
    
    /** record that a given player made a move at the given position
     * checks that the given positions is on the board
     * checks that the player number is valid 
     */
    public void addMove(Coordinate c, int player) {
        try{ // try catch block to log exceptions to logcat. prints message based on error.
            if (player < 7) {
                board[c.getX()][c.getY()] = player;
            } else if (player == 7){
                AI ai = new AI();
                Coordinate aiMove = ai.aiAddMove(board);
                board[aiMove.getX()][aiMove.getY()] = player;
            }
        } catch(IllegalArgumentException e){
            if (c.checkBoundaries(size, size)){
                Log.e("myTag", "(" + c.getX() + "," + c.getY() + ") coordinate was out of bounds, where on earth did you click?", e);
            } else if (player > size) {
                Log.e("myTag", "player number " +  player + "is illegal!", e);
            } else {
                Log.e("myTag", "Don't even know what went wrong here, i'm impressed!", e);
            }
        }
    }

    /** returns true if, and only if, there are no more free positions on the board */
    public boolean checkFull() {
        boolean isFull = true;
        for (int i = 0; i < getSize(); i++){
            for (int n = 0; n < getSize(); n++) {
                if (board[i][n] == 0) {
                    isFull = false;
                }
            }
        }
        return isFull;
    }

    /** returns 0 if no player has won (yet)
     * otherwise returns the number of the player that has three in a row
     */
    public int checkWinning() {
        int winner = 0;
        for (int j = 0; j < getSize() - 2; j++) {
            for (int i = 0; i < getSize(); i++){
                Coordinate startCol = new XYCoordinate(i,j); // Checking columns
                winner = checkSequence(startCol, 0,1);
                if (winner != 0){
                    return winner;
                }
                Coordinate startRow = new XYCoordinate(j,i); // Checking rows
                winner = checkSequence(startRow, 1,0);
                if (winner != 0){
                    return winner;
                }
            }
        }
        for (int i = 0; i < getSize() - 2; i++ ) { // Checking diagonals that run from top left to bottom right
            for (int j = 0;j < getSize() - 2; j++ ) {
                Coordinate start = new XYCoordinate(i,j);
                winner = checkSequence(start, 1,1);
                if (winner != 0){
                    return winner;
                }
            }
        }
        for (int i = 0; i < getSize() - 2; i++ ) { // Checking diagonals that run from bottom right to top left
            for (int j = getSize() - 1;j > 1; j-- ) {
                Coordinate start = new XYCoordinate(i,j);
                winner = checkSequence(start, 1,-1);
                if (winner != 0){
                    return winner;
                }
            }
        }
        return winner;
    }
    
    /** internal helper function checking one row, column, or diagonal */
    private int checkSequence(Coordinate start, int dx, int dy) {
        int checkValue = board[start.getX()][start.getY()];
        if (checkValue == 0) {
            return 0;
        }
        for (int i = 2; i > 0; i--){ // runs next block twice to check two positions away from start
            start = start.shift(start, dx, dy);
            if (checkValue != board[start.getX()][start.getY()]){
                return 0;
            }
        }
        return checkValue;
    }
    
    /** getter for size of the board */
    public int getSize() {
        return this.size;
    }
    
    /** pretty printing of the board
     * useful for debugging purposes
     */
    public String toString() {
        String result = "";
        for (int y = 0; y < this.size; y++) {
            for (int x = 0; x < this.size; x++) {
                result += this.board[y][x]+" ";
            }
            result += "\n";
        }
        return result;
    }
}
