package dm550.tictactoe;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class AI {
    /**hold the currently best move*/
    private Coordinate bestMove;

    /**list to hold moves with equal value*/
    List<Coordinate> bestMoveList =  new ArrayList<>();

    /**used for deciding best nextMove*/
    private int bestValue;

    /** current paths score, gets compared to bestScore to evaluate move*/
    private int currentValue;

    /**value of board pos that leads to win*/
    private int winValue = 100;

    /**value of board pos that leads to loss*/
    private int lossValue = 79; // a value of 80 here resulted in a few cases where the ai either didn't take a winning move and instead blocked the player

    /**value of board position with my marker*/
    private int myValue = 10;

    /**same as above but negative*/
    private int oppValue = -10;

    /**temporary value holders*/
    private int tempValue1;
    private int tempValue2;

    /** aiAddMove method for AI */
    public Coordinate aiAddMove(int[][] board){
        return generateMove(board);
    }

    /**method for generating moves*/
    private Coordinate generateMove(int[][] board){
        Random rnd = new Random();
        for (int x = 0; x < 3; x++){
            for (int y = 0; y < 3; y++){
                if (board[x][y] == 0){
                    currentValue = moveEvaluate(x, y, board);
                    if (currentValue == bestValue){
                        bestMoveList.add(new XYCoordinate(x,y));
                    } else if (currentValue > bestValue){
                        bestValue = currentValue;
                        bestMoveList.clear();
                        bestMoveList.add(new XYCoordinate(x,y));
                    }
                }
            }
        }
        if(bestMoveList.isEmpty()) { // if human player starts and places marker in 1,1 moveEvaluate will return -10 for the 8 free positions and therefore never set a bestMove
            bestMoveList.add(new XYCoordinate(0, 0));
            bestMoveList.add(new XYCoordinate(1, 2));
            bestMoveList.add(new XYCoordinate(2, 1));
            bestMoveList.add(new XYCoordinate(2, 2));
        }
        if (bestMoveList.size() == 2) { // exception to standard AI rule to force a corner placement in case where human -> 1,1 AI goes Corner human goes opposite corner.
            if (((bestMoveList.get(0).getX() == 0 && bestMoveList.get(0).getY() == 1) && (bestMoveList.get(1).getX() == 1 && bestMoveList.get(1).getY() == 2)) ||
                (bestMoveList.get(0).getX() == 1 && bestMoveList.get(0).getY() == 0) && (bestMoveList.get(1).getX() == 2 && bestMoveList.get(1).getY() == 1))  {
                bestMoveList.clear();
                bestMoveList.add(new XYCoordinate(0, 0));
                bestMoveList.add(new XYCoordinate(2, 2));
            } else if (((bestMoveList.get(0).getX() == 0 && bestMoveList.get(0).getY() == 1) && (bestMoveList.get(1).getX() == 1 && bestMoveList.get(1).getY() == 0)) ||
                (bestMoveList.get(0).getX() == 1 && bestMoveList.get(0).getY() == 2) && (bestMoveList.get(1).getX() == 2 && bestMoveList.get(1).getY() == 1)) {
                bestMoveList.clear();
                bestMoveList.add(new XYCoordinate(2, 0));
                bestMoveList.add(new XYCoordinate(0, 2));
            }
        }
        bestMove = bestMoveList.get(rnd.nextInt(bestMoveList.size())); // picks a random Coordinate from the list
        if(bestValue == 0 && board[1][1] == 0){ // to force the ai to make a move in 1,1 if the ai starts or if the human player started but didn't choose 1,1.
            bestMove = new XYCoordinate(1,1);
        }
        return bestMove;
    }

    private int moveEvaluate(int x, int y, int[][] board){
        tempValue1 = checkRow(y, board) + checkCol(x, board) + checkDiaUp(x, y, board) + checkDiaDown(x, y, board);
        return tempValue1;
    }

    private int checkRow(int y, int[][] board){ // only passing y as it will remain the same and x changes in the for loop
        tempValue2 = 0;
        for (int x = 0; x < 3; x++){
            if (board[x][y] == 7){
                tempValue2 += myValue;
            } else if (board[x][y] == 1) {
                tempValue2 += oppValue;
            }
        }
        if (tempValue2 == 20){ // if tempValue2 == 20 means ai can win by placing marker here
            tempValue2 = winValue;
        } else if(tempValue2 == -20) {
            tempValue2 = lossValue; // if tempValue2 == -20 means ai will lose unless marker is placed here
        }
        return tempValue2;
    }

    private int checkCol(int x, int[][] board){ // only passing x as it will remain the same and y changes in the for loop
        tempValue2 = 0;
        for (int y = 0; y < 3; y++){
            if (board[x][y] == 7){
                tempValue2 += myValue;
            } else if (board[x][y] == 1) {
                tempValue2 += oppValue;
            }
        }
        if (tempValue2 == 20){
            tempValue2 = winValue;
        } else if(tempValue2 == -20) {
            tempValue2 = lossValue;
        }
        return tempValue2;
    }

    private int checkDiaUp(int x, int y, int[][] board){
        tempValue2 = 0;
        if ((x == 2 && y == 0) || (x == 1 && y == 1) || (x == 0 && y == 2)){ // only runs if there is a diagonal to check
            for (int i = 0; i < 3; i++){
                if(board[i][2 - i] == 7){
                    tempValue2 += myValue;
                } else if (board[i][2 - i] == 1) {
                    tempValue2 += oppValue;
                }
            }
        }
        if (tempValue2 == 20){
            tempValue2 = winValue;
        } else if(tempValue2 == -20) {
            tempValue2 = lossValue;
        }
        return tempValue2;
    }

    private int checkDiaDown(int x, int y, int[][] board){
        tempValue2 = 0;
        if ((x == 0 && y == 0) || (x == 1 && y == 1) || (x == 2 && y == 2)) {
            for (int i = 0; i < 3; i++) {
                if (board[i][i] == 7) {
                    tempValue2 += myValue;
                } else if (board[i][i] == 1) {
                    tempValue2 += oppValue;
                }
            }
        }
        if (tempValue2 == 20) {
            tempValue2 = winValue;
        } else if (tempValue2 == -20) {
            tempValue2 = lossValue;
        }
        return tempValue2;
    }
}
